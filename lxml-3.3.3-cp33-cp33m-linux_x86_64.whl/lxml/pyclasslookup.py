# dummy module for backwards compatibility

from etree import PythonElementClassLookup
